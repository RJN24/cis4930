# Flask Template

# Description
A flask template with mySQL, simple authentication, jQuery, and Bootstrap 4